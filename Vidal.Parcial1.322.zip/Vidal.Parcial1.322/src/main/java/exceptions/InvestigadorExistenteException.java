
package exceptions;

public class InvestigadorExistenteException extends RuntimeException {
    public InvestigadorExistenteException(String mensaje) {
        super(mensaje);
}
}


