
package exceptions;

public class ModeloExistenteException extends RuntimeException {
    public ModeloExistenteException(String mensaje) {
        super(mensaje);
}
}


