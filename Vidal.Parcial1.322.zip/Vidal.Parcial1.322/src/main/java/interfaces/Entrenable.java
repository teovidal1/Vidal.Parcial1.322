
package interfaces;

public interface Entrenable {
    void entrenar();
}
