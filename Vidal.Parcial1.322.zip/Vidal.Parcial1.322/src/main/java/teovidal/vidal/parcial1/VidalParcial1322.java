package teovidal.vidal.parcial1;
import interfaces.*;
import models.*;


public class VidalParcial1322 {

    public static void main(String[] args) {
        CentroEntrenamiento centro = new CentroEntrenamiento("centroprueba");
        Investigador inv = new Investigador ("Juan",3, centro);
        RedNeuronal red = new RedNeuronal(4,"nombre1","Lab1",TipoDato.DATOS_NUMERICOS);
        RedNeuronal red2 = new RedNeuronal(5,"nombre1","Lab1",TipoDato.DATOS_NUMERICOS);

        inv.agregarModelo(red);
        inv.agregarModelo(red2);
        
        centro.mostrarModelos();
        centro.entrenarModelos();
        centro.filtrarPorTipoDatos(TipoDato.DATOS_NUMERICOS);
    }
}
