
package models;
import java.util.List;
import java.util.ArrayList;
import exceptions.InvestigadorExistenteException;
import interfaces.Entrenable;

public class CentroEntrenamiento {
    private final String nombre;
    private List<ModeloIA> modelos;
    private List<Investigador> investigadores;

    public CentroEntrenamiento(String nombre) {
        this.nombre = nombre;
        this.modelos = new ArrayList<>();
        this.investigadores = new ArrayList<>();
    }

    public String getNombre() {
        return nombre;
    }

    public List<ModeloIA> getModelos() {
        return modelos;
    }

    public List<Investigador> getInvestigadores() {
        return investigadores;
    }
    
    public boolean validarInvestigadorNuevo(Investigador inv){
        
        if (inv==null){
            throw new NullPointerException ("Inválido, ingreso de datos vacío");
        }
       
        for (Investigador invest : investigadores ){
            if (invest.equals(inv)){
            throw new InvestigadorExistenteException("El investigador ya está registrado");
        }} 
        
        return true;
        }

    public void agregarInvestigador(Investigador inv){
            if (validarInvestigadorNuevo(inv))
            investigadores.add(inv);}

    
    public void mostrarModelos() {
    
    for (ModeloIA modelo : modelos){ 
        System.out.println("Nombre: " + modelo.getNombre() + "Laboratorio: " + modelo.getLaboratorioAsignado() +
        "Tipo de datos: " + modelo.getTipoDato() + "Detalles " + modelo.getDetalles());
    
    }}
    
    public void entrenarModelos(){
    for (ModeloIA m : modelos){
            if (m instanceof Entrenable){
               ((Entrenable) m).entrenar(); } 
            else{System.out.println("No puede entrenarse el modelo "+ m.getNombre() + " Porque es del tipo " + m.getClass());
            
            }}}
            
    public void filtrarPorTipoDatos(TipoDato tipo) {

    for (ModeloIA modelo : modelos) {
        if (modelo.getTipoDato() == tipo) {
            System.out.println("Modelo" + modelo.getNombre() + "Tipo de dato: " + modelo.getTipoDato() );
        }
    }}}







      