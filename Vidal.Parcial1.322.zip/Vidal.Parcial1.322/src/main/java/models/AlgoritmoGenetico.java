
package models;


public class AlgoritmoGenetico extends ModeloIA{
    private double tasaMutacionIdeal;

    public AlgoritmoGenetico(double tasaMutacionIdeal, String nombre, String laboratorioAsignado, TipoDato tipoDato) {
        super(nombre, laboratorioAsignado, tipoDato);
        this.tasaMutacionIdeal = tasaMutacionIdeal;
    }
    
    public double getTasaMutacionIdeal(){
        return tasaMutacionIdeal;
    }
    
    @Override
    public String toString(){
        return ("Algoritmo Genetico"+ super.getNombre() + "Laboratorio: "+ super.getLaboratorioAsignado());
    }
    
    public String getDetalles(){
        return ("tasa Mutacion ideal:  " + tasaMutacionIdeal);
    }
}
