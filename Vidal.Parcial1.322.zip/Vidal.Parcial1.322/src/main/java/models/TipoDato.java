
package models;


public enum TipoDato {
    DATOS_NUMERICOS, DATOS_TEXTUALES
}
