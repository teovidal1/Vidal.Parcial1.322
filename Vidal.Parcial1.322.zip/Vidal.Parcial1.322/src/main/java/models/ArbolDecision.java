
package models;
import interfaces.Entrenable;


public class ArbolDecision extends ModeloIA implements Entrenable {
    private String criterioDivision;

    public ArbolDecision(String criterioDivision, String nombre, String laboratorioAsignado, TipoDato tipoDato) {
        super(nombre, laboratorioAsignado, tipoDato);
        this.criterioDivision = criterioDivision;
    }
    
    public String getCriterioDivision(){
        return criterioDivision;
    }
    
    @Override
    public void entrenar(){
        System.out.println("Entrenando el Arbol de Decisiones "+ super.getNombre());
    }
    
    @Override
    public String toString(){
        return ("Arbol de Decision "+ super.getNombre() + "Laboratorio: "+ super.getLaboratorioAsignado());
    }
    
    public String getDetalles(){
        return ("criterio Division: " + criterioDivision);
    }
}
