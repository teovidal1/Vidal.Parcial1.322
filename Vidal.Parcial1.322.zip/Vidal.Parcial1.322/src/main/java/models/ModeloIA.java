
package models;


public abstract class ModeloIA {
    private String nombre;
    private String laboratorioAsignado;
    private TipoDato tipoDato;

    public ModeloIA(String nombre, String laboratorioAsignado, TipoDato tipoDato) {
        this.nombre = nombre;
        this.laboratorioAsignado = laboratorioAsignado;
        this.tipoDato = tipoDato;
    }

    public String getNombre() {
        return nombre;
    }

    public String getLaboratorioAsignado() {
        return laboratorioAsignado;
    }

    public TipoDato getTipoDato() {
        return tipoDato;
    }
    
    
    
    @Override
    public String toString(){
       return ("Modelo IA" + nombre); //Esto lo escribo pero las subclases lo sobreescriben despues
    }
    
    public String getDetalles(){
        return ("Detalles: "+ nombre + laboratorioAsignado);
    }
    
    
}
