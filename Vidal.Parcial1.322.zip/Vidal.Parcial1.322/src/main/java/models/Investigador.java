
package models;
import java.util.Objects;
import exceptions.ModeloExistenteException;

public class Investigador {
    private String nombre;
    private int id;
    private CentroEntrenamiento centroEnt;

    public Investigador(String nombre, int id, CentroEntrenamiento centroEnt ) {
        this.nombre = nombre;
        this.id = id;
        this.centroEnt = centroEnt;


    }
    public String getNombre() {
        return nombre;
    }

    public int getId() {
        return id;
    }
    
    public void agregarModelo (ModeloIA modelo){
        if (validarModeloNuevo(modelo)){
            centroEnt.getModelos().add(modelo);
        }
    }
    
    public boolean validarModeloNuevo(ModeloIA mod){
        
        if (mod==null){
            throw new NullPointerException ("Inválido, ingreso de datos vacío");
        }
       
        for (ModeloIA mod1 : centroEnt.getModelos()){
            if (mod1.getNombre()==mod.getNombre()){
            throw new ModeloExistenteException("El modelo ya está registrado");
        }} 
        
        return true;
        }
    
    
    
    
    @Override
    public boolean equals(Object o){
        if (this == o) return true;
        if (!(o instanceof Investigador))return false;
        Investigador pr = (Investigador) o;
        return nombre.equals(pr.nombre);
        
    }
    
    @Override
    public int hashCode(){
        return Objects.hash(nombre);
    }
    
    
    
}
