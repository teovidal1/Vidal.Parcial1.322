
package models;
import interfaces.Entrenable;

public class RedNeuronal extends ModeloIA implements Entrenable {
    private int cantidadMaximaCapas;

    public RedNeuronal(int cantidadMaximaCapas, String nombre, String laboratorioAsignado, TipoDato tipoDato) {
        super(nombre, laboratorioAsignado, tipoDato);
        this.cantidadMaximaCapas = cantidadMaximaCapas;
    }
    
    @Override
    public void entrenar(){
        System.out.println("Entrenando la red neuronal "+ super.getNombre());
    }
    
    @Override
    public String toString(){
        return ("Red neuronal"+ super.getNombre() + "Laboratorio: "+ super.getLaboratorioAsignado());
    }
    
    public int getCantidadMaximaCapas(){
        return cantidadMaximaCapas;
    }
    
    public String getDetalles(){
        return ("Cantidad maxima capas: " + cantidadMaximaCapas);
    }
}



